# blit7s

v0.0.1 created by Armaan Aggarwal



A python package for RPi.GPIO that allows you to blit characters on a 7 segment unit.


**Development stage is at alpha**
